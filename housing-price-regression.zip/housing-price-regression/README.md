# Housing Price Regression: EDA, Preprocessing and Feature Engineering

This repository contains an exploratory analysis of a housing-price dataset (`eda.ipynb`), a
reusable, leakage-safe preprocessing pipeline built from its findings (`src/preprocessing.py`), a ladder of
baseline models with an evaluation framework (`src/models.py`, `src/evaluation.py`), a feature engineering and
selection module (`src/feature_engineering.py`) that is validated against the baseline, and two advanced models of different
architectures (boosted trees and a neural network, `src/advanced_models.py`) compared with the baseline under nested cross-validation. Experiments are configured with version-controlled YAML/JSON files, and every
run is recorded under its own run ID (`src/experiment.py`). The regression target is `house_sale_price`.

```
raw data -> DataPreprocessor -> FeatureEngineer -> FeatureSelector -> model -> metrics
            (preprocessing.py)   (feature_engineering.py)          (models.py, evaluation.py)
```

> **Problem type: regression.** The target, `house_sale_price`, is a continuous price, so the project uses regression metrics
> (RMSE, MAE, MAPE, R-squared, bias), regression baselines, and cross-validation of numeric errors.
> **Not applicable by design:** classification metrics (accuracy, precision/recall, F1, ROC-AUC), probability outputs, decision-threshold
> tuning, class-imbalance handling (oversampling, class weights) and temporal features (the data has no dates). Stratification is used only to keep
> `location_type` proportions equal across the splits; it is not class balancing.

> **Submitting or sharing this project?** Submit the **whole repository**, not individual files: `main.py` imports five modules from `src/`
> (`preprocessing`, `feature_engineering`, `models`, `evaluation`, `experiment`), and each one is needed. Run
> `python scripts/verify_clean_checkout.py --zip submission.zip` first; it checks completeness and runs everything from a clean copy
> (see [Checking that the repository is complete](#checking-that-the-repository-is-complete)).

## Quick start

```bash
pip install -r requirements.txt          # developed with Python 3.12; the final checks ran on scikit-learn 1.9, pandas 3.0 (earlier work on scikit-learn 1.8)

python main.py                           # preprocess the data and print what was learned
python main.py --baseline                # benchmark the baseline models (about 5 seconds)
python main.py --baseline --validation-size 0.1   # same, with a separate validation set (70% train / 10% validation / 20% test)
python main.py --advanced --no-tuning   # compare boosted trees and a neural network with the baseline, fixed settings (about 20 seconds)
python main.py --advanced               # the full protocol: hyperparameters tuned inside every cross-validation fold (about 6 minutes)
python main.py --features                # add feature engineering + selection and save the results
python main.py --validate                # run the 18-check validation suite and a baseline model
python main.py --compare-features        # cross-validated comparison of feature sets (about 3 minutes with --compare-models)
python main.py --config configs/default.yaml --features   # run from a config file
python -m pytest                         # run the 368 unit tests
python scripts/verify_clean_checkout.py  # prove the repository is complete: checks, then tests + validation in a clean copy
python main.py --help                    # every option
```

Each run that saves files writes into a folder named after its **run ID** (for example
`reports/20261105-142530-3fa9c1d2/`), so runs never overwrite each other.

### Command-line reference

| Option | Meaning |
|---|---|
| `--config FILE` | load a YAML/JSON experiment config; command-line options override it |
| `--save-config FILE` | write the resolved configuration (defaults + config file + options) and exit |
| `--baseline` | benchmark the baseline ladder (mean predictor ... preprocessed linear regression) with cross-validation and a hold-out test |
| `--candidates` | with `--baseline`: also benchmark Ridge, Lasso, Elastic Net, random forest, gradient boosting and the engineered-feature model |
| `--advanced` | compare the baseline with the two advanced models (boosted trees, neural network) using nested cross-validation, a hold-out test and a detailed analysis |
| `--advanced-screen` | the model-selection screening of 12 architectures that led to the two advanced models |
| `--no-tuning`, `--tune-iterations N`, `--inner-folds N`, `--nn-seeds N` | advanced models: skip the hyperparameter search; settings tried per search (12); inner CV folds (3); network seeds averaged (5) |
| `--features` | engineer and select features after preprocessing |
| `--selection-method M` | `none, variance, correlation, vif, univariate, lasso, rfe, tree, consensus`; chain with `+` (`vif+rfe`) |
| `--compare-features` | cross-validated comparison of feature sets, then one check on the test set |
| `--compare-models` | with `--compare-features`: also try Ridge, gradient boosting and random forest |
| `--validate` | run the validation suite and a baseline model (non-zero exit code on failure) |
| `--scaler`, `--outlier-strategy`, `--outlier-iqr-factor`, `--target-transform` | preprocessing choices |
| `--numeric-imputer {median,mean,constant,knn}`, `--categorical-imputer`, `--missing-indicator` | imputation |
| `--feature-selection {none,variance,lasso}` | selection built into the preprocessor (separate from `--selection-method`, which belongs to the feature-engineering stage) |
| `--output-dtype {float64,float32}` | dtype of the processed features (`float32` halves their memory) |
| `--categorical-encoding {onehot,frequency,hashing,target,auto}` | categorical encoding |
| `--clip-z X`, `--cv-folds N`, `--cv-repeats N`, `--seed N`, `--test-size X` | feature engineering, evaluation and split settings (`--clip-z 0` switches winsorising off) |
| `--data`, `--output-dir`, `--artifact-dir`, `--reports-dir` | input and output locations |
| `--run-label TEXT`, `--no-versioning`, `--no-save` | name a run, use the flat folder layout, or write nothing |
| `--validation-size X` | hold out this share of all rows as a validation set (0.1 with the default test size 0.2 gives 70/10/20; default 0 = none) |
| `--profile` | track peak Python memory per stage |
| `-v` / `--verbose`, `-q` / `--quiet` | `--verbose`: also show INFO messages from the library modules (what each fit learned); `--quiet`: only warnings and errors (files are still written) |

### Where the outputs go

| Folder | Content (per run, inside `<folder>/<run_id>/`) |
|---|---|
| `processed/` | `X_train.csv`, `X_test.csv`, `y_train.csv`, `y_test.csv`; with `--features` also `features_X_train.csv`, `features_X_test.csv` |
| `artifacts/` | `preprocessor.joblib`; with `--baseline` also `baseline_model.joblib`; with `--advanced` also `gradient_boosting_model.joblib` and `neural_network_model.joblib`; with `--features` also `feature_pipeline.joblib` (fitted end-to-end pipeline) |
| `reports/` | `results.json` (full run record, including the reload checks), `run.log` (everything the run printed and logged), `config.yaml` (resolved config), `feature_catalog.csv`, `feature_selection_report.csv`; with `--baseline` also `baseline_cv_comparison.csv`, `baseline_holdout_metrics.csv`, `baseline_holdout_predictions.csv`, `baseline_residuals_by_price_band.csv`, `baseline_residuals_by_group.csv`, `baseline_diagnostics.png` (and `baseline_validation_metrics.csv` with `--validation-size`); with `--compare-features` also `feature_set_comparison.csv`, `holdout_comparison.csv`; with `--advanced` also `advanced_cv_comparison.csv`, `advanced_holdout_metrics.csv`, `advanced_holdout_predictions.csv`, `advanced_versus_reference.csv`, `advanced_error_by_price_band.csv`, `advanced_error_by_location.csv`, `advanced_blends.csv`, `advanced_complexity.csv`, `advanced_permutation_importance.csv`, `advanced_tuning.csv`, `advanced_comparison.png` (and `advanced_screening.csv` with `--advanced-screen`) |
| `reports/runs.csv` | one line per run (run ID, config hash, command, key results) to list and compare runs |
| `<folder>/latest.txt` | the ID of the newest run in that folder |

All three folders are git-ignored. `--no-versioning` writes directly into `processed/`, `artifacts/` and `reports/` instead.

## Repository structure

```
your-repo-name/
├── README.md
├── eda.ipynb                     # exploratory analysis with executed outputs
├── requirements.txt              # runtime and test dependencies
├── requirements-dev.txt          # + ruff, mypy, pre-commit
├── main.py                       # CLI: preprocess, engineer features, compare, validate, record runs
├── pyproject.toml                # ruff and mypy configuration
├── pytest.ini                    # test configuration
├── .pre-commit-config.yaml       # git hooks (lint, format, types, tests before push)
├── .github/workflows/ci.yml      # CI: lint, type check, tests, validation on Python 3.9 / 3.11 / 3.12
├── Housing_Price_Dataset.csv     # raw data (1,000 rows, 9 columns)
├── configs/
│   ├── default.yaml              # every default setting, ready to copy
│   └── example_advanced.yaml     # KNN / per-column imputation, auto encoding, chained selection
├── examples/
│   └── compare_encoders.py       # encoder comparison on synthetic high-cardinality data
├── results/
│   └── advanced/                 # outputs of the full advanced run: tables, figure, screening, resolved config
├── scripts/
│   └── verify_clean_checkout.py  # completeness checks + tests and validation in a clean copy; builds the submission zip
├── src/
│   ├── __init__.py
│   ├── preprocessing.py          # cleaning, imputation, outliers, scaling, encoding
│   ├── models.py                 # baseline ladder, BaselineModel, candidate models, benchmark harness
│   ├── advanced_models.py        # boosted trees, neural network, nested tuning, comparison analysis
│   ├── evaluation.py             # metrics, residual diagnostics, cross-validation, model comparison test
│   ├── feature_engineering.py    # feature creation, feature selection, feature-set evaluation
│   └── experiment.py             # config files, run IDs, profiling, run records
└── tests/
    ├── conftest.py               # shared fixtures (small synthetic dataset)
    ├── test_preprocessing.py     # 111 tests
    ├── test_feature_engineering.py   # 68 tests
    ├── test_evaluation.py        # 27 tests (metrics, residual report, CV, corrected t-test)
    ├── test_models.py            # 32 tests (baseline estimators, ladder, benchmark, validation set, no test set)
    ├── test_advanced_models.py   # 41 tests (seed averaging, nested tuning, builders, analysis)
    ├── test_experiment.py        # 28 tests (config files, run IDs, profiling, reload verification)
    ├── test_main.py              # 43 tests (command line, logging, versioned outputs, reload checks, advanced run, portable configs)
    └── test_repository_integrity.py   # 18 tests (completeness, imports, README matches the code)
```

## Data splitting and validation strategy

| Setting | Rows | Used for |
|---|---|---|
| **Default (two-way + cross-validation)** | 800 train, 200 test | Models are compared by repeated 5-fold cross-validation **on the training rows**; the test rows are used once at the end |
| **Optional three-way split** (`--validation-size 0.1`) | 700 train, 100 validation, 200 test | Models are fitted on the training rows and also scored on the validation rows; cross-validation on the training rows still works; the test rows are used once at the end |

- **Stratification.** Both splits are stratified on `location_type`, so the small Rural group is represented equally everywhere (the three-way split
  has exactly 50% / 40% / 10% Suburban / Urban / Rural in every part).
- **Same test set either way.** The test rows are split off first with the same seed, so they are identical with and without a validation set
  (tested); the validation rows are taken out of the training rows.
- **No leakage.** Imputation values, outlier fences, log floors, scaler statistics, encoders, engineered-feature statistics and selected columns are all learned
  from the training rows only and then applied unchanged to the validation and test rows. Inside cross-validation the whole pipeline is refitted on each training fold.
- **Which to use?** On 1,000 rows cross-validation is the steadier way to choose between models, which is why it is the default; a separate validation
  set is useful as an extra, independent check (and is available when a three-way split is required). Whatever you choose, decisions are made on cross-validation or validation
  scores and the test set is reported last.

Results with the three-way split (`python main.py --baseline --validation-size 0.1`, reference baseline, 700 training rows):
cross-validated RMSE 25,490 (R-squared 0.961), **validation RMSE 21,450** (R-squared 0.960, 92% of predictions within 10%), **test RMSE 28,681** (R-squared 0.959).
The ladder keeps the same order on the validation set (mean predictor 108,099; best single feature 91,268; raw linear regression 34,728; reference 21,450).
The validation set has only 100 rows, so its numbers move around more than the cross-validated ones.

## Saved artifacts are reloaded and checked

Saving a file does not prove it can be used. After each artifact is written (`preprocessor.joblib`, `baseline_model.joblib`, `feature_pipeline.joblib`) the run reloads it from disk,
runs it on 5 raw test rows and checks that the output is finite and **identical to the in-memory object's output**. A failed check stops the run with an
`ArtifactVerificationError`. The outcome of every check is stored under `artifact_checks` in `results.json`, and the same helper is available as
`src.experiment.verify_saved_artifact(path, sample, method="predict", expected=...)`.

## Logging

Everything the command-line program reports goes through Python's `logging` (the `main` logger, plain-message format on stdout), not `print`, so it can be silenced
(`-q`), redirected, or captured. Each run that saves files also writes `run.log` into its report folder with timestamps, containing the program output **and** the INFO messages of the library
modules (what each preprocessing and feature-engineering fit learned, stage timings). On the console the library messages appear on stderr with `-v`. A test checks that `main.py`
contains no `print` calls.

## Checking that the repository is complete

`main.py` depends on all five modules in `src/`. A submission with only some of them cannot run, and nothing in the files you did include would tell you.
`scripts/verify_clean_checkout.py` makes that impossible to miss:

```bash
python scripts/verify_clean_checkout.py                         # static checks, then tests + validation in a clean copy
python scripts/verify_clean_checkout.py --quick                 # only the static checks (a second)
python scripts/verify_clean_checkout.py --zip submission.zip    # also write a zip containing exactly the verified files
```

1. **Static checks:** every required file exists; every `from src.x import name` points at a file *and a name that is really defined there*; every third-party
   package that is imported is listed in `requirements.txt`.
2. **Clean copy:** the repository is copied to a temporary folder without generated outputs, caches or `.git`.
3. **Run:** the unit tests and `main.py --validate` run inside that copy.

`tests/test_repository_integrity.py` repeats the static checks inside the test suite, proves that they fail when a module, function, requirement or required file is removed,
and keeps the documentation honest: every file in the structure tree above exists, every Python module is listed in it, every command-line option in this README exists (and every real option is
documented), the test counts shown here equal the real test counts, and this README states that the problem is regression.

## Configuration files

An experiment is described by a YAML or JSON file with up to six sections: `run`, `preprocessing`
(every field of `PreprocessingConfig`), `feature_engineering` (every field of `FeatureEngineeringConfig`),
`selection`, `cv` and `advanced` (`tune`, `tune_iterations`, `inner_folds`, `nn_seeds`). Missing settings use the defaults, and **unknown keys are rejected** so typos are caught
immediately. Precedence is *defaults < config file < command-line options*.

```yaml
# my_experiment.yaml
preprocessing:
  scaler: robust
  group_imputer_strategies: {numeric: knn}
  imputer_overrides: {age_of_property: mean}
feature_engineering:
  add_tiers: false
selection:
  method: vif+rfe
cv: {folds: 5, repeats: 3}
```

```bash
python main.py --save-config configs/mine.yaml --scaler robust       # create a config from options
python main.py --config configs/mine.yaml --features                  # run it
python main.py --config reports/<run_id>/config.yaml --features       # exactly repeat an earlier run
```

Every saving run stores the **resolved** configuration as `config.yaml` next to its results, so any run can be repeated. Rerunning from a
saved config gives the same config hash and the same selected features (this is tested).

## Experiment tracking

Each run that saves files produces `reports/<run_id>/results.json`, a single machine-readable record with:

- the run ID (`UTC timestamp - configuration hash`, plus a label if given; a suffix `-2`, `-3` is added if the same ID already exists), start/finish time and command line
- the environment (Python, platform, package versions) and a fingerprint of the data (SHA-256, rows, columns)
- the resolved configuration and its hash
- stage timings (and peak memory with `--profile`)
- results: preprocessing summary, imputation and encoding reports, the baseline benchmark (all metrics for every fold), feature catalog and
  selection report, the feature-set cross-validation table **with fold-level scores**, the hold-out results and the validation checks

`reports/runs.csv` accumulates one summary line per run. To load a run in Python: `json.load(open("reports/<run_id>/results.json"))`.

## How the EDA findings map to pipeline decisions

| EDA finding | Pipeline decision |
|---|---|
| No missing values or duplicates in the raw data | Still handled so the module is reusable: median / most-frequent imputation, duplicate removal, rows with a missing target dropped |
| `crime_rate_in_area` (skew 2.55), `property_size` (2.02), `proximity_to_public_transport` (1.52) are right-skewed; `log(crime)` lifts the correlation with price from -0.40 to -0.50 | These three features are log-transformed (`SafeLogTransformer`) |
| IQR outliers in features and target look genuine, not errors | The target is never filtered. Features are only **clipped** at extreme fences (Q1 - 3 x IQR, Q3 + 3 x IQR), which touches about 0.5% of numeric training values (22 of 4,000); switch off with `--outlier-strategy none` |
| `number_of_bedrooms` / `number_of_bathrooms` are already z-scores (mean about 0, std about 1) | Imputed only, not scaled again |
| Target `house_sale_price` is right-skewed (1.57); log gives 0.27 | Reversible log target (Box-Cox optional), applied through `TransformedTargetRegressor` so predictions return to the price scale |
| `location_type` has three nominal levels and only 100 Rural rows | One-hot encoding (first level dropped, unseen categories become all zeros); train/test split stratified on `location_type` |
| VIF is at most about 2.8 | No feature removal or decorrelation step needed |

## What the pipeline does

| Column group | Steps (all fitted on the training set only) |
|---|---|
| Log features | impute (median) -> clip outliers -> safe log -> standard scale |
| Other numeric (`age_of_property`, `school_quality_score`) | impute -> clip outliers -> standard scale |
| Standardised (`number_of_bedrooms`, `number_of_bathrooms`) | impute only |
| Categorical (`location_type`) | impute (most frequent) -> one-hot encode |
| Missing flags (optional) | 0/1 column for every feature that had missing values in training |
| Feature selection (optional) | `variance` drops constant columns; `lasso` keeps columns with a non-zero LassoCV coefficient |

Row-level cleaning (`clean_data`) happens before the split because it learns nothing from the data:
whitespace and case in categories are normalised, unparseable numbers become NaN (and are then
imputed), exact duplicates are removed, and rows whose target is missing or non-positive are removed.

## What the pipeline reports about itself

After `fit`, the preprocessor explains what it learned:

| Attribute / function | Content |
|---|---|
| `imputation_report_` | per column: group, strategy, fill value, number and share of missing training values |
| `imputation_report(X)` | the same counts for any new data (test set, new batch), using the training fill values |
| `outlier_bounds_`, `count_clipped(X)` | learned fences and how many values fall outside them |
| `log_floors_` | the floor used by the safe log for each log feature |
| `feature_selection_report_`, `dropped_features_` | which output columns were kept or dropped, with their variance or Lasso score |
| `fit_summary_` | headline facts: rows, imputed values, clipped values, scaler, one-hot columns, final feature count |
| `split_distribution_report(...)` | train/test counts and shares of the stratification column, and train/test target statistics |

The same facts are written to the log at INFO level when the preprocessor is fitted (run `python main.py -v`).
For example, on data with missing cells:

```
Imputation (numeric=median, categorical=most_frequent): {'age_of_property': 32, 'location_type': 41, ...}
Outlier clipping at 3.0 x IQR: {'crime_rate_in_area': 10, 'property_size': 9, ...}
Scaler: standard
One-hot encoding created 2 column(s) from ['location_type']
Output feature space: 9 feature(s) from 8 input column(s)
```

## Baseline model and evaluation

### What the baseline is

A baseline answers "how good is a model built with almost no effort?" so that every later model has a concrete number to beat.
`src/models.py` provides a **ladder** of baselines, from useless to sensible. All take the raw feature table and predict the price in price units.

| Rung | Model | Question it answers |
|---|---|---|
| floor | mean price (ignores all features); median price | what if we ignore every feature? |
| naive | mean price per `location_type` (`GroupMeanRegressor`) | what does the only categorical feature give us? |
| naive | best single feature + straight line (`BestSingleFeatureRegressor`; it picks `property_size`) | how far does the strongest single predictor go? |
| naive | linear regression on the raw columns | what does a model with no preprocessing achieve? |
| **reference** | **linear regression + the project preprocessing, on log(price)** (`BaselineModel`) | **the benchmark to beat** |

The reference baseline is the simplest model that uses the preprocessing decisions from the EDA (imputation, outlier capping, logs of skewed
features, scaling, one-hot location, log target). It is fast, has no tunable hyperparameters, and is easy to interpret.

### Evaluation protocol

- Every model is cross-validated on the **800 training rows only** (5-fold, repeated 3 times; identical folds for all models, which is tested).
- The **200 test rows are used once**, after cross-validation, for the final hold-out numbers.
- All metrics are computed on the **original price scale**, so models with different internal target transforms are comparable.
- A difference to the reference is tested with the corrected resampled t-test (the plain paired t-test is over-confident on repeated-CV folds).

### Metrics and why

The EDA found a right-skewed price with a few very expensive homes, so no single metric is enough. `src/evaluation.py` computes all of these
(`metric_definitions()` returns this table as a DataFrame):

| Metric | Meaning | Why it is here |
|---|---|---|
| **RMSE** (primary) | square root of the mean squared error | headline number in price units; dominated by the expensive homes |
| MAE | mean absolute error | typical miss; robust to the expensive tail |
| MAPE and within 10% | relative error; share of predictions within 10% of the true price | a 20,000 miss matters more on a cheap home; easy to explain |
| R-squared (and adjusted) | share of price variance explained | the mean predictor scores about 0 |
| bias | mean of (prediction - truth) | systematic over- or under-prediction, hidden by RMSE and MAE |
| RMSLE, median AE, max error, RMSE as % of mean price, explained variance | secondary views | log-scale error, typical case, worst case |

### Results

Cross-validation on the training set (RMSE and MAE in price units; MAPE and within-10% in percent):

| Model | CV RMSE | CV MAE | CV MAPE | CV R2 | within 10% |
|---|---|---|---|---|---|
| mean price | 127,173 | 95,134 | 29.9 | -0.004 | 23.5 |
| median price | 129,371 | 92,776 | 27.1 | -0.039 | 24.2 |
| mean price per location | 124,432 | 93,367 | 29.1 | 0.037 | 23.5 |
| best single feature (`property_size`) | 92,441 | 68,674 | 20.8 | 0.460 | 31.6 |
| linear regression, raw columns | 44,007 | 31,048 | 9.8 | 0.877 | 65.3 |
| **reference: linear regression + preprocessing (log target)** | **25,149** | **17,250** | **4.9** | **0.960** | **88.6** |

Hold-out test set (each model evaluated once):

| Model | RMSE | MAE | MAPE | R2 | within 10% | bias |
|---|---|---|---|---|---|---|
| mean price | 143,441 | 101,148 | 29.0 | -0.013 | 23.0 | -16,274 |
| mean price per location | 140,805 | 97,938 | 28.0 | 0.024 | 24.0 | -16,274 |
| best single feature | 93,914 | 72,486 | 20.4 | 0.566 | 26.0 | -8,304 |
| linear regression, raw columns | 51,070 | 35,082 | 9.9 | 0.872 | 65.5 | -2,540 |
| **reference baseline** | **29,191** | **19,084** | **5.1** | **0.958** | **88.5** | **-1,141** |

**Reading the numbers**

- **The floor behaves as it should.** The mean predictor has R-squared near 0 (it is slightly negative on the test set, whose average price is higher than the
  training average). Mean price per location improves it only to R-squared 0.04, which agrees with the EDA's finding that location explains a small share of price.
- **Each rung is a real improvement.** The best single feature explains about half the variance; a plain linear regression on all raw columns reaches 0.88;
  preprocessing and the log target take it to 0.96 and cut the cross-validated RMSE from 44,007 to 25,149 (43% lower). The share of homes predicted within 10% rises from 65% to 89%.
- **The reference baseline predicts a typical home to within about 5%** (MAPE 5.1%, MAE 19,084 on the test set, against an average price of about 350,000).
- **Cross-validation and the test set agree**, apart from RMSE being higher on the test set (29,191 against 25,149), which is mostly because the test set contains the most
  expensive homes (the largest single miss is a 1.2 million home predicted at about 1.0 million).

### Where the baseline makes its errors

`python main.py --baseline` also prints a residual report and saves a four-panel diagnostics figure (`baseline_diagnostics.png`) for the reference model on the test set:

| True-price band (test set) | mean error | mean error % | MAE |
|---|---|---|---|
| Q1 (cheapest fifth) | +5,288 | +2.0% | 13,536 |
| Q2 | +5,816 | +2.1% | 15,505 |
| Q3 | +4,916 | +1.5% | 14,264 |
| Q4 | -3,510 | -0.8% | 16,519 |
| Q5 (most expensive fifth) | -18,217 | -2.4% | 35,598 |

- **Errors grow with price.** The most expensive fifth has 2.6 times the MAE of the cheapest fifth, and the correlation between absolute error and true price is 0.61. This is why RMSE
  (dominated by expensive homes) is so much larger than MAE.
- **The model shrinks towards the middle:** it over-predicts cheap homes and under-predicts expensive ones. By location the bias is small (Rural -0.8%, Suburban +0.8%, Urban +0.4%).
- **It is not a log back-transformation problem.** I tested the standard correction (multiplying predictions by the mean of the exponentiated training residuals, "smearing"): the factor is 1.002 and
  RMSE improves by only 0.3%. The under-prediction of expensive homes is a modelling limitation (a straight line in log space cannot capture the curvature the EDA found), which the
  engineered features address (next section). This check is not part of the code.

### Foundation for comparison and improvement

`python main.py --baseline --candidates` runs the same protocol on ready-made challengers (`candidate_specs()` in `src/models.py`). These are **untuned** (default or simple settings),
so they show the starting point for the next stage, not final results:

| Challenger | CV RMSE | CV R2 | vs reference (RMSE) | hold-out RMSE |
|---|---|---|---|---|
| ridge (alpha 10) | 26,335 | 0.956 | 4.7% worse (p = 0.003) | 29,722 |
| lasso (alpha 0.001) | 25,675 | 0.958 | 2.1% worse (p = 0.014) | 29,628 |
| elastic net | 25,396 | 0.959 | 1.0% worse (p = 0.032) | 29,377 |
| gradient boosting (defaults) | 32,775 | 0.932 | 30.3% worse (p = 0.005) | 35,721 |
| random forest (200 trees) | 45,216 | 0.872 | 79.8% worse (p < 0.001) | 47,744 |
| linear regression + engineered features (VIF) | 19,151 | 0.977 | **23.9% better** (p = 0.0002) | 19,397 |

The main lesson is that **this reference baseline is hard to beat by changing the model alone**: regularised linear models do no better, and default tree ensembles are clearly worse. The gain comes from
better features. To add a model, give `run_benchmark` a `BaselineSpec(name, build, description, tier)`; it will be cross-validated on identical folds and compared to the reference with the
corrected t-test, and its results go into `results.json` automatically. Hyperparameter tuning of the challengers is the natural next step and is not part of this baseline.

```python
from src.models import BaselineModel, baseline_specs, candidate_specs, run_benchmark

baseline = BaselineModel().fit(raw_X_train, y_train)
baseline.evaluate(raw_X_test, y_test)  # dictionary of all metrics, price scale

result = run_benchmark(raw_X_train, y_train, raw_X_test, y_test, baseline_specs(), n_splits=5, n_repeats=3)
result.comparison  # CV metrics, skill vs the mean predictor, gain vs the reference, p-values
result.holdout  # the single test-set evaluation
result.residuals["by_price_band"]  # where the reference makes its errors
result.save("reports/baseline")  # CSV tables, predictions and diagnostics figure
```

### Limitations of the baseline evaluation

- One dataset and one random split with 200 test rows; the test-set numbers have wide uncertainty, and a handful of expensive homes move RMSE noticeably.
  Cross-validated numbers on 800 rows are the steadier reference.
- The reference baseline's preprocessing choices (log of three features, 3 x IQR capping, log target) came from the EDA, which looked at all 1,000 rows. That is mild but real
  information flow from the test rows into the baseline's design.
- The challengers are untuned, so "tree models are worse" means "with default settings on 800 rows", not "trees cannot do better".

## Feature engineering and selection

### Where the features come from

`FeatureEngineer` runs **after** preprocessing, so it works on data that is already complete, log-transformed,
standardised and one-hot encoded. Each engineered column is a product or transformation of standardised
columns, so everything is centred and on a comparable scale. 48 features are created from the 9 preprocessed
columns. Each one has a documented reason in `FeatureEngineer.feature_catalog_` (also saved to `reports/feature_catalog.csv`).

| Group | Count | Examples | Why (EDA, domain knowledge, diagnostics) |
|---|---|---|---|
| Polynomial (squares) | 7 | `crime_sq`, `transit_sq`, `age_sq` | The EDA found a curved crime effect (section 3.3). Residual plots of the baseline model showed a U-shape for transport (both very central and very remote homes cost more), a hump for crime and a curve for age. Squares let a linear model fit these. |
| Interactions | 21 | `size_x_school`, `age_x_transit` | One feature changing the effect of another (EDA sections 5.1-5.4). Pairs with the strongest signal in diagnostics included age x transit and size x school. |
| Group interactions | 14 | `crime_x_rural`, `size_x_urban` | Location-specific slopes: the size-price slope differed by location (87 / 80 / 66, section 5.1). |
| Composites | 4 | `nbhd_quality`, `rooms_total`, `spaciousness`, `transit_extremity` | Domain ideas: buyers pay for a "safe area with good schools" package, bedrooms and bathrooms (r = 0.68) describe one living-space dimension, size relative to rooms, and distance of the transport value from typical. |
| Tiers | 2 | `crime_tier`, `school_tier` | Low / mid / high thresholds, as in the EDA's 3 x 3 tier grid (section 5.4). |

A data caveat shaped the design: `number_of_bedrooms` and `number_of_bathrooms` are standardised values (the EDA
found negative "counts"), so true ratios like "size per bedroom" are impossible. The composites use differences and
averages in z-units instead.

### Feature selection techniques

`FeatureSelector` is a scikit-learn transformer. Inside a pipeline it is fitted on each training fold only, so
selection never sees validation or test data.

| Method | Rule |
|---|---|
| `variance` | drop (near-)constant columns |
| `correlation` | among columns correlated above a threshold keep the one most related to the target |
| `vif` | repeatedly drop the highest variance-inflation-factor column until all are below a threshold (default 10); removes exact and near-exact linear combinations |
| `univariate` | F-test against the target, Bonferroni-adjusted, or top-k |
| `lasso` | keep columns with a non-zero LassoCV coefficient |
| `rfe` | recursive feature elimination with Ridge, size chosen by cross-validation or fixed |
| `tree` | random-forest importance (top-k or 95% cumulative importance) |
| `consensus` | keep columns chosen by at least *m* of several methods |

Methods can be chained (`selector=["vif", "rfe"]`). `always_keep` protects columns; `make_full_pipeline` protects the
original features and location dummies by default (see the lessons below for why).

### Results

All numbers below come from `python main.py --compare-features --compare-models`, using a linear regression on the
log target. Scenarios are compared by 5-fold cross-validation repeated 3 times **on the 800 training rows only**
(feature creation and selection are refitted inside every fold). The test set is used once at the end. RMSE and MAE are
in price units; the p-value is a corrected resampled t-test (cautious because repeated CV folds overlap).

| Feature set | Features | CV RMSE | CV MAE | CV R2 | RMSE gain | p-value |
|---|---|---|---|---|---|---|
| baseline (no engineering) | 9 | 25,149 | 17,250 | 0.960 | | |
| composites only | 13 | 27,495 | 16,550 | 0.934 | -9.3% | 0.84 |
| **polynomial (squares) only** | 16 | 19,299 | 14,018 | 0.976 | 23.3% | 0.0001 |
| interactions only | 30 | 22,127 | 15,925 | 0.969 | 12.0% | 0.002 |
| group interactions only | 23 | 24,820 | 16,992 | 0.961 | 1.3% | 0.48 |
| tiers only | 11 | 24,227 | 16,833 | 0.963 | 3.7% | 0.054 |
| all engineered, no selection | 57 | 21,881 | 14,193 | 0.964 | 13.0% | 0.64 |
| all + correlation filter | 57 | 21,881 | 14,193 | 0.964 | 13.0% | 0.64 |
| all + univariate F-test | 31 | 22,988 | 15,131 | 0.963 | 8.6% | 0.70 |
| all + Lasso | 42 | 21,795 | 14,114 | 0.964 | 13.3% | 0.63 |
| all + RFE | 31 | 22,079 | 14,207 | 0.963 | 12.2% | 0.67 |
| all + random-forest importance | 36 | 26,039 | 16,377 | 0.948 | -3.5% | 0.92 |
| all + consensus | 40 | 23,033 | 14,768 | 0.960 | 8.4% | 0.77 |
| **all + VIF** | 48 | 19,151 | 13,766 | 0.977 | 23.9% | 0.0002 |
| all + VIF then Lasso | 37 | 19,303 | 13,835 | 0.977 | 23.2% | 0.0004 |
| **all + VIF then RFE** | 28 | 19,158 | 13,752 | 0.977 | 23.8% | 0.0001 |

**Hold-out test set** (200 rows, used once after the choices above):

| Model | RMSE | MAE | R2 |
|---|---|---|---|
| baseline | 29,191 | 19,084 | 0.958 |
| all + VIF (lowest CV RMSE) | 19,397 | 13,985 | 0.982 |
| polynomial only (simplest within 1 standard error) | 22,800 | 14,860 | 0.974 |

### What the evidence says (and the lessons)

1. **Squares carry most of the gain.** Seven squared terms alone cut CV RMSE by 23%. Interactions add more on top;
   group interactions and tiers add little by themselves.
2. **Three of the four composites add nothing for a linear model.** `nbhd_quality`, `rooms_total` and `spaciousness`
   are exact linear combinations of existing columns. Removing all composites, with no selection at all, gives the same
   error as the best model (19,102 vs 19,151). They also make the design matrix numerically singular (condition number about
   2 x 10^15), so plain least squares can produce wild predictions for a few extreme houses; this is why "all engineered, no selection" has a
   *better MAE* than the baseline but a *worse RMSE* (its five worst predictions account for 71% of its squared error). They are kept
   for interpretability and because a VIF filter removes them. `transit_extremity` is different: it is non-linear and does
   carry signal (a model with only the composites and VIF improved RMSE by about 10%).
3. **Selection must suit the model.** Random-forest importance selection hurt a linear model (-3.5%), because it
   keeps what trees use rather than what a linear model needs. The univariate test ignores redundancy. The VIF filter
   fits the actual problem (collinearity) and was best.
4. **Protect the main effects.** An unprotected VIF filter removed all seven original features (they correlate most
   with the engineered terms) and left a model of interactions without main effects: RMSE 50,062 versus 19,151 when protected.
   This is the hierarchy principle, and there is a regression test for it.
5. **Feature engineering helps linear models, not tree ensembles.** Ridge improved by about 21 to 22%. Gradient boosting
   (+2%, p = 0.73) and random forest (+3%, p = 0.24) did not improve significantly, and after VIF selection they got
   worse. Trees find curvature and interactions on their own. Also note that a plain linear model on this data beats gradient boosting and
   random forests with default settings (CV RMSE 25k versus 32k and 45k), which fits the EDA's finding of smooth, mostly additive relationships.

### Honest limitations of this evaluation

- **The feature ideas were not designed on the training set alone.** Residual diagnostics and exploratory tests used all 1,000 rows,
  including what later became the test set. The cross-validated comparison and the hold-out test are clean for *choosing among
  the scenarios*, but the choice of feature families, the VIF default and `clip_z = 3` were partly informed by looking at all
  the data. The hold-out improvement (about 34%) is therefore likely a little optimistic. The cross-validated gain
  (about 24%) is the more cautious number.
- `clip_z = 3` (winsorising standardised features before building squares and products) was chosen after seeing it help slightly in
  cross-validation. Its effect is small.
- 200 test rows from one random split is a small sample. The test set also contains the most expensive homes (target skew 1.90 against 1.45 in training), which inflates its RMSE for every model.
- One dataset, one target. The findings (especially "composites add nothing" and "trees do not benefit") describe this data.
- Several feature-set comparisons are not statistically significant (see p-values); the claims above are limited to the clear
  differences (squares, VIF, the baseline gap).

### Using the module

```python
from sklearn.linear_model import LinearRegression
from src.feature_engineering import FeatureEngineeringConfig, FeatureEngineer, FeatureSelector, make_full_pipeline

# End-to-end: preprocessing -> feature engineering -> VIF selection -> model (raw data in, price-scale predictions out)
model = make_full_pipeline(LinearRegression(), fe_config=FeatureEngineeringConfig(), selector="vif")
model.fit(raw_X_train, y_train)
model.predict(raw_X_test)

# Inspect what was created and kept
fe = model.regressor_.named_steps["features"]
fe.feature_catalog_  # name, group, formula and rationale of every engineered feature
model.regressor_.named_steps["select"].dropped_features_
model.regressor_.named_steps["select"].selection_report_

# Chain selectors, or switch feature groups off
make_full_pipeline(LinearRegression(), fe_config=FeatureEngineeringConfig(add_tiers=False), selector=["vif", "rfe"])
```

`FeatureEngineeringConfig` switches each group on or off (`add_composites`, `add_polynomial`, `add_interactions`,
`add_group_interactions`, `add_tiers`), restricts the features or pairs used, sets `clip_z` and the number of tiers, and maps
roles to column names so the module can be reused on other data. `evaluate_feature_sets(...)` compares any set of scenarios by
repeated cross-validation; `select_best_scenario(...)` picks the lowest-RMSE scenario or, with the one-standard-error rule, the
simplest scenario within one standard error of it.

## Advanced models

### The two models and why these two

The baseline is one linear equation on log(price). The sprint asks for two further models with **distinct architectures**, so they were chosen by a
**screening** of architecture families rather than by name: every candidate gets the baseline's preprocessing and log target, the same folds and the
same metrics, with fixed untuned settings, cross-validated on the 800 training rows only (`python main.py --advanced-screen`). The screening never even predicts the test set (the benchmark runs without one, which is tested), so it cannot influence the choice.

| Architecture (screening, 5-fold CV x 3, untuned) | CV RMSE | CV R2 | vs linear | p-value |
|---|---|---|---|---|
| mean price (floor) | 127,173 | -0.004 | | |
| linear regression (the baseline model) | 25,149 | 0.960 | | |
| ridge | 26,335 | 0.956 | 4.7% worse | 0.003 |
| **neural network, 2 layers (64, 32)** | **21,791** | **0.970** | **13.4% better** | 0.033 |
| neural network, 1 layer (32) | 24,464 | 0.962 | 2.7% better | 0.53 |
| kernel ridge (RBF) | 22,317 | 0.968 | 11.3% better | 0.13 |
| support vector regression (RBF) | 27,918 | 0.951 | 11.0% worse | 0.36 |
| **gradient boosting (500 trees)** | **28,421** | 0.949 | 13.0% worse | 0.047 |
| gradient boosting (defaults) | 32,775 | 0.932 | 30.3% worse | 0.005 |
| histogram gradient boosting | 35,622 | 0.921 | 41.6% worse | < 0.001 |
| extra trees | 42,230 | 0.889 | 67.9% worse | < 0.001 |
| random forest | 45,584 | 0.870 | 81.3% worse | < 0.001 |
| k-nearest neighbours | 45,415 | 0.872 | 80.6% worse | < 0.001 |

- **Boosted trees** represent the tree family: a sequence of hundreds of shallow decision trees, each correcting the previous ones. They were the best tree-based model by a wide margin.
- **A neural network** (a feed-forward multi-layer perceptron) represents the smooth, flexible non-tree family. It was the best non-tree model. Kernel ridge came close and is statistically
  indistinguishable from the network (it is a sensible candidate for future work); the network was chosen because it was nominally best, can be tuned over depth and width, and scales better.
- Both are genuinely different from the baseline: a fixed linear form (baseline) versus piecewise-constant steps learned from data (trees) versus smooth curves learned from data (network).

### Design of the two models (`src/advanced_models.py`)

| | Gradient boosted trees | Neural network |
|---|---|---|
| Implementation | scikit-learn `GradientBoostingRegressor` | scikit-learn `MLPRegressor` (Adam optimiser), no extra dependencies |
| Inputs | the baseline's preprocessed features (9 columns) | the same |
| Target | log(price) | log(price), standardised (networks train much better on a centred target) |
| Tuned by randomized search | trees (200 to 800), learning rate, depth (2 to 4), subsample, minimum leaf size | layers and width (32 to 128x64), L2 penalty, learning rate, activation (ReLU or tanh) |
| Variance control | `subsample < 1` (stochastic boosting) | **average of 5 networks with different random seeds** (single seeds differed by about 2 to 3% in RMSE; averaging five gave a lower RMSE in the exploratory comparison, though not a statistically significant one, p = 0.24) |

Both models receive exactly the baseline's inputs, so the architecture is the only difference. Engineered features were tested (an exploratory 5-fold x 2 comparison on the training rows, fixed settings) and **made both models worse**
(network 19,569 to 24,227 RMSE, p = 0.015; boosted trees 26,279 to 28,992, p = 0.054), because they learn their own non-linearity and the extra correlated columns only add overfitting on 800 rows.

### Evaluation protocol: nested cross-validation

- **Tuning cannot peek.** Hyperparameters are chosen by randomized search (12 settings, 3-fold inner cross-validation, scored by price-scale RMSE) on the training rows,
  and the search runs **inside every outer fold** (nested cross-validation), so the reported scores are not flattered by tuning on the data they are measured on.
  The preprocessing is refitted in every inner fold as well.
- **Same folds and metrics as the baseline**, 5-fold x 3 repeats, with the corrected resampled t-test for every difference to the reference.
- **The test set is used once**: the final models are tuned on the full training set and evaluated on the 200 test homes.
- Every random choice derives from one seed. The tuned settings of each outer fold are recorded (`advanced_tuning.csv`).
- The search tries the same 12 candidate settings in every fold (same seed), so "stability" below means consistency of the choice among them.

### Results

The tables, figure, screening and resolved configuration of exactly this run (seed 42) are stored in `results/advanced/`, so the results can be inspected without rerunning it
(`python main.py --config results/advanced/config.yaml --advanced` repeats it). `python main.py --advanced` (about 6 minutes on one CPU, timings vary with the machine; `--no-tuning` about 20 seconds; `--cv-repeats 1` about 2 minutes). Cross-validated on the training set (nested for the tuned models):

| Model | CV RMSE (std) | CV MAE | CV MAPE | CV R2 | within 10% | RMSE vs baseline | p-value | fit time |
|---|---|---|---|---|---|---|---|---|
| baseline: linear + preprocessing | 25,149 (2,733) | 17,250 | 4.90% | 0.960 | 88.6% | | | 0.03 s |
| linear + engineered features (previous sprint) | 19,151 (1,237) | 13,766 | 4.00% | 0.977 | 95.1% | 23.9% better | 0.0002 | 0.07 s |
| gradient boosted trees | 24,809 (2,462) | 17,572 | 4.99% | 0.961 | 88.8% | 1.4% better | **0.87** | 13.7 s |
| neural network (5 seeds) | 19,247 (1,243) | 13,980 | 4.08% | 0.977 | 95.2% | 23.5% better | 0.0007 | 7.3 s |

Hold-out test set (200 homes, each model evaluated once):

| Model | RMSE | MAE | MAPE | R2 | within 10% | bias | RMSE vs baseline |
|---|---|---|---|---|---|---|---|
| baseline | 29,191 | 19,084 | 5.09% | 0.958 | 88.5% | -1,141 | |
| linear + engineered features | 19,397 | 13,985 | 3.79% | 0.981 | 96.0% | +438 | 33.6% better |
| gradient boosted trees | 29,171 | 19,129 | 5.18% | 0.958 | 92.0% | -2,122 | 0.1% better |
| **neural network** | **18,975** | **13,509** | **3.71%** | **0.982** | **95.5%** | +618 | **35.0% better** |

How reliable are the test-set differences? A bootstrap of the 200 test homes gives, for the RMSE improvement over the baseline: neural network **+10,216** (95% interval 4,145 to 16,552),
engineered linear +9,794 (4,206 to 15,682), boosted trees **+20 (-3,789 to 4,362, no difference)**. The network has a smaller absolute error than the baseline on 64.5% of the homes, the
engineered linear model on 65.0%, boosted trees on 50.0%.

### Analysis of the relative performance

**1. The network matches the best hand-crafted model; the trees do not beat the baseline.**
The neural network and the previous sprint's engineered linear model are **statistically tied** (cross-validated RMSE difference 97 in the linear model's favour, corrected p = 0.81; the network wins in
one third of the folds but wins on the test set). They reach the same accuracy by different routes: the network learns the curvature and interactions that the linear model needed hand-built features for.
Boosted trees are significantly worse than the network (p = 0.0002) and indistinguishable from the baseline (p = 0.87). On this smooth, low-dimensional, mostly additive problem (the EDA found
smooth effects and a log-linear structure) a piecewise-constant model needs many steps to approximate what a line or a smooth curve captures directly, and with only 800 rows it cannot.

**2. Where the gains come from: the expensive homes.** MAE by true-price band on the test set:

| Price band | baseline | linear + engineered | boosted trees | neural network |
|---|---|---|---|---|
| Q1 (cheapest fifth) | 13,536 | 9,561 | 14,728 | 10,134 |
| Q2 | 15,505 | 9,919 | 14,197 | 9,451 |
| Q3 | 14,264 | 10,710 | 14,138 | 10,448 |
| Q4 | 16,519 | 15,482 | 16,763 | 14,034 |
| Q5 (most expensive fifth) | 35,598 | 24,251 | 35,820 | 23,480 |

Mean error as a percentage of price in the most expensive fifth: baseline **-2.4%** (under-predicts), boosted trees -1.5%, linear + engineered +0.1%, network +0.6%. The baseline's shrinkage towards the
middle (diagnosed in the baseline analysis) is largely removed by the network, while boosted trees keep it. Boosted trees are also the only model with the largest bias in the cheapest band (+3.4%).

**3. By location.** MAE on the test set: Suburban 21,608 (baseline), 14,625 (network), 19,139 (trees); Urban 16,253, 10,460, 15,514; **Rural 17,791, 20,142, 33,539**.
The network and the engineered linear model help in Suburban and Urban but are slightly *worse than the baseline in Rural*, and boosted trees are much worse there. Only 20 test homes are Rural (and 80 training homes), so this is
a warning sign, not a finding, but it is the clearest reason not to assume the advanced models are better everywhere.

**4. The models make partly different mistakes.** Correlation of test errors: network and engineered linear 0.91 (nearly the same mistakes), baseline and network 0.66, trees and network 0.76, baseline and trees 0.64. A simple 50/50
average of the network and the engineered linear model has a test RMSE of 18,728 (against 18,975 for the best single model and 19,397), a small gain that is expected from averaging and was not tuned; the average of the baseline and the network
(22,021) is worse than the network alone.

**5. All models rely on the same features** (share of permutation importance on the test set): `property_size` 19 to 22%, `proximity_to_public_transport` **20 to 22%**, `crime_rate_in_area` 14 to 15%, then school quality, bathrooms, bedrooms, location and age (6 to 13% each).
The strong, consistent importance of the transport variable in every architecture confirms that its signal is real (the EDA found it counterintuitive and its meaning is still unconfirmed). Trees and the network use school quality somewhat more than the
linear model does (13.2% and 10.5% against 8.9%).

**6. Cost.** Complexity, speed and size:

| Model | Parameters | File size | Fit time | Predict time |
|---|---|---|---|---|
| baseline | 10 coefficients | 20 KB | 0.03 s | 0.05 ms / home |
| linear + engineered | 49 coefficients | 43 KB | 0.07 s | 0.10 ms / home |
| boosted trees | 5,362 tree nodes (800 trees of depth 2) | 595 KB | 16.0 s (includes the search) | 0.07 ms / home |
| neural network | 48,005 weights (5 networks of 128 x 64) | 1,581 KB | 7.4 s (includes the search) | 0.08 ms / home |

All are fast enough for prediction. The linear models can be read off as coefficients; the other two cannot without extra tools (permutation importance above is a coarse substitute).

**7. Stability of the tuning.** Boosted trees chose the same settings (800 trees, learning rate 0.05, depth 2, subsample 0.6, minimum leaf 5) in 14 of 15 outer folds and for the final model; one fold chose 400 trees with learning rate 0.1. The network chose
ReLU in every fold, with two settings: 128 x 64 units, L2 0.0008, learning rate 0.001 (10 folds and the final model) or 64 units, L2 0.0038, learning rate 0.01 (5 folds). The inner-CV RMSE was 25,080 to 29,381 for boosted trees and 19,715 to 21,130
for the network (inner scores are optimistic and use less training data, which is why the outer scores are the ones to quote).

### Which model would I use?

- **Best accuracy with the least manual work:** the neural network. It needs no hand-built features and is the best model by RMSE, MAE and MAPE on the test set.
- **Equally accurate and far simpler, if the feature code is acceptable:** the engineered linear model (49 readable coefficients, 43 KB, fits in 0.07 s). The cross-validation cannot separate it from the network (it is nominally ahead there: 19,151 against 19,247; the network is ahead on the test set).
- **Boosted trees:** not competitive here (no better than the baseline, and hundreds of times slower to fit, search included). This does not say trees are bad in general, only that this data is smooth and small.
- The baseline remains the right reference: every claim above is relative to it.

### Limitations and caveats

- **One dataset, 1,000 rows, one 200-home test set.** Test-set differences have wide uncertainty (see the bootstrap intervals), and a few expensive homes dominate RMSE. The Rural results rest on 20 test homes.
- **The tuning is modest** (12 of 324 boosted-tree settings, 12 network settings), so these are not the best possible versions of each architecture. More search, other tree libraries (XGBoost, LightGBM) or deeper or wider networks might change the gap, especially for trees.
  No extra dependency was added.
- **Nested cross-validation removes tuning optimism from the scores, not selection effects of the screening**, which looked at the training rows with fixed settings. The test set was not used for any decision, but the EDA and the preprocessing design saw all 1,000 rows, as noted before.
- **The blends and permutation importance use the test set** for insight only; they were not used to choose models.
- Single-seed neural networks vary by a few percent; the five-seed average reduces that but the result is still one run of a stochastic method.
- **Not tested:** other feature sets for the advanced models than the baseline's, stacking with a fitted meta-model, calibration of prediction intervals.

## Using the preprocessing module

```python
from sklearn.linear_model import Ridge
from src.preprocessing import (
    PreprocessingConfig,
    load_data,
    run_preprocessing,
    make_model_pipeline,
)

cfg = PreprocessingConfig()  # defaults follow the EDA
df = load_data("Housing_Price_Dataset.csv")

# 1) Step by step: processed arrays for any model
res = run_preprocessing(df, cfg)
res.X_train, res.X_test  # DataFrames with readable column names
res.y_train_transformed  # log(price)
res.preprocessor.outlier_bounds_  # fences learned on the training data

# 2) As a single estimator: cross-validation / grid search without leakage
model = make_model_pipeline(Ridge(alpha=1.0), cfg)
model.fit(res.raw_X_train, res.y_train)  # raw features, raw price
model.predict(res.raw_X_test)  # predictions back on the price scale
```

`DataPreprocessor` follows the scikit-learn estimator API (`fit`, `transform`, `get_feature_names_out`,
`clone`), so it can be used in any `Pipeline`. `save()` and `load()` persist a fitted preprocessor.

### Configuration

All choices live in `PreprocessingConfig`; the most useful are:

| Option | Default | Alternatives |
|---|---|---|
| `scaler` | `"standard"` | `"robust"`, `"minmax"`, `"none"` |
| `outlier_strategy` / `outlier_iqr_factor` | `"clip"` / `3.0` | `"none"`; 1.5 for stricter capping |
| `target_transform` | `"log"` | `"boxcox"`, `"none"` |
| `numeric_imputer_strategy` / `numeric_fill_value` | `"median"` / `0.0` | `"mean"`, `"constant"`, `"knn"` (with `knn_neighbors`) |
| `imputer_overrides`, `group_imputer_strategies` | `{}` | per-column / per-group strategy, e.g. `{age_of_property: mean}`, `{numeric: knn}` |
| `categorical_encoding` | `"onehot"` | `"frequency"`, `"hashing"`, `"target"`, `"auto"` (see below) |
| `encoding_overrides`, `max_onehot_cardinality`, `high_cardinality_encoding`, `hashing_n_features` | `{}`, `10`, `"target"`, `8` | per-column encoding; the rule used by `"auto"` |
| `categorical_imputer_strategy` / `categorical_fill_value` | `"most_frequent"` / `"Missing"` | `"constant"` |
| `add_missing_indicator` | `False` | `True` adds 0/1 flag columns |
| `feature_selection` / `variance_threshold` | `"none"` / `0.0` | `"variance"`, `"lasso"` |
| `output_dtype` | `"float64"` | `"float32"` (halves output memory) |
| `log_features`, `standardised_features`, `categorical_features` | from the EDA | any column lists |
| `test_size`, `random_state`, `stratify_column` | `0.2`, `42`, `"location_type"` | |

### Imputation and categorical encoding options

**Imputation.** `median`, `mean`, `constant` and `knn` are available for numeric columns, set globally, per column group
(`group_imputer_strategies`: `log_numeric`, `numeric`, `standardised`) or per column (`imputer_overrides`). Columns that use
`knn` in the same group are imputed together from similar rows; a single knn column falls back to its mean. Categorical columns use
`most_frequent` or `constant`. `add_missing_indicator` adds 0/1 flag columns.

**Encoding.** The dataset's only categorical column, `location_type`, has 3 levels, so one-hot encoding is the default and is used
throughout the EDA-driven design (the location interactions in the feature engineering rely on its dummy columns). For higher-cardinality
columns the pipeline offers:

| Encoding | What it does | Notes |
|---|---|---|
| `onehot` | one 0/1 column per category (first dropped) | best when there are few categories; unseen categories become all zeros |
| `frequency` | the category's share of the training rows (1 column) | works for any cardinality but cannot tell apart categories with the same share |
| `hashing` | hashes categories into `hashing_n_features` count columns | fixed width, handles unseen categories, but collisions blur categories |
| `target` | smoothed mean of the target per category (1 column) | needs `y`; training features are **cross-fitted** (5-fold) so no row is encoded with its own target, which `DataPreprocessor.fit_transform` handles; unseen categories get the overall target mean |
| `auto` | one-hot when a column has at most `max_onehot_cardinality` categories in the training data, else `high_cardinality_encoding` | the plan is stored in `encoding_plan_` / `encoding_report_` |

`python examples/compare_encoders.py` compares them on synthetic data with a 60-category column whose categories each have their own price
effect (5-fold CV R-squared with linear regression): one-hot 0.931 (68 features), **target 0.925 (9 features)**, hashing 0.264, frequency 0.104.
Frequency and hashing do poorly here because category identity matters; they are mainly useful when the *share* of a category or a fixed memory
budget matters. These numbers come from synthetic data and show behaviour, not a result about the housing data.

## Testing and validation

**Unit tests** (`python -m pytest`, 368 tests, about 1.5 minutes) use a small synthetic dataset from `tests/conftest.py`
so they do not depend on the real CSV. They cover:

- configuration validation (invalid values and conflicting column roles are rejected)
- `clean_data` (duplicates, missing and non-positive targets, text normalisation, input not modified)
- `split_data` (stratification, reproducibility) and `split_distribution_report`
- `IQROutlierClipper` and `SafeLogTransformer` in isolation
- `DataPreprocessor`: output shape and names, no NaN, leakage (test features scaled with training statistics,
  checked against a hand computation), unseen categories, extra or missing columns, determinism, scalers,
  float32 output, save/load, `clone`
- imputation: all strategies, exact missing counts in the report, text treated as missing, missing-indicator columns, fit-time logging
- feature selection in the preprocessor (variance and Lasso, including the "needs y" error)
- `FeatureEngineer`: every group and its formulas checked by hand, standardisation with training statistics (no leakage),
  winsorising, NaN propagation, constant columns, tiers from training quantiles, switches and custom pairs, error handling
- `FeatureSelector`: every method on a synthetic frame with known signal, noise, a near-duplicate and a constant column;
  `n_features`, protection, consensus votes, the "needs y" error, VIF behaviour (including the main-effects regression test) and chained selectors
- imputation options (per-column, per-group, KNN) and every categorical encoder, including a test that target-encoded training features are cross-fitted
- configuration: dictionary and YAML/JSON round trips, unknown keys rejected, defaults < file < command line precedence
- `src/advanced_models.py`: seed averaging (members differ only by seed, reproducible, convergence reported), the tuning wrapper (picks the better setting, `final_params` only for the final refit, deterministic, works inside an outer
  cross-validation and records its choices), every search parameter existing on its estimator, the network's standardised target, both models on clean and dirty data, the screening catalogue, the analysis functions against hand calculations and
  known cases (price bands, bootstrap, complexity counts, permutation importance), and the whole comparison on a small problem
- the advanced command line: settings precedence for the `advanced` section, files, figures, saved models with reload checks, the validation-set variant and the screening
- the optional validation set: three-way sizes, stratification, disjoint rows, identical test rows with and without it, training-only statistics, the validation table in the benchmark
- reload verification of saved artifacts: good files, outputs that differ, wrong shapes, missing, corrupt or unusable files, NaN output, and a failing check stopping the run
- logging: no `print` in `main.py`, `-q` silences the output, no duplicated output or leaked handlers across runs, `run.log` contents, library messages only with `-v`
- repository integrity (see above), including tampered copies that must fail
- `src/experiment.py`: config hashing, run IDs (including collisions), versioned folders, JSON conversion, profiling, run record and registry
- the command line end to end: versioned outputs, `results.json`, rerunning from a saved config, `--no-save`, `--no-versioning`
- `src/evaluation.py`: every metric checked against hand calculations and scikit-learn, bias sign, relative-metric edge cases, input validation, the residual report
  (errors growing with price, regression to the mean), fold-level cross-validation (refits a clone on the training part only, identical folds across models) and the corrected t-test against its formula
- `src/models.py`: group-mean and best-single-feature estimators (unseen and messy categories, missing values), the ladder order and tiers, every baseline fitting on clean and dirty data,
  the benchmark tables and their semantics, determinism, saving, JSON export, and `BaselineModel` save/load
- pipelines and evaluation: price-scale predictions, missing values and unseen categories, cross-validation with selection inside,
  the corrected p-value checked against a manual calculation, the one-standard-error rule, and a curved-data test where engineering must help
- target transforms (round trip and skew), model pipelines on the original price scale, cross-validation
  with missing values, and an end-to-end run on deliberately dirty data

To check that the tests are meaningful, bugs were injected on purpose (a clipper that does not clip, a scaler that uses the
test set's own statistics, a wrong composite formula, an engineered-feature scaler that leaks test statistics, selector protection removed, ensemble members sharing one seed, an ignored final-refit setting, an unstandardised network target, a flipped bootstrap sign, the mean predictor leaking into the analysis, a wrong-signed bias, a mis-scaled MAPE, a group-mean model without its unseen-category fallback, models evaluated on different folds, cross-validation that trains on the validation rows, leaky target-encoding output, an ignored
per-column imputer override, run-ID collisions, a config file overriding the command line)
and the suite failed as it should each time.

**Validation script** (`python main.py --validate`) runs 18 checks on the real data and exits with a non-zero status if any fail:
no NaN/inf in outputs, scaling statistics, leakage, skew reduction, outlier capping, robustness to corrupted data,
correct imputation report, reversible target transform, save/load, split proportions, cleaning, config validation, an
end-to-end linear baseline, leak-free and deterministic feature engineering, the engineered + selected pipeline beating the baseline on the test set, evaluation metrics matching hand-computed values, the baseline ladder being ordered with a mean predictor near R-squared 0, and both advanced models fitting, predicting sensible prices and being reproducible. The baseline prints test R-squared of about 0.86 with a raw target and about 0.96 with the log target
(plain linear regression, seed 42). It is only a sanity check of the pipeline, not a modelling result.

## Performance notes and profiling

The pipeline is written for clarity and safety first. Measured on 300,000 rows (about 51 MB as a DataFrame, one unused column):

| | float64 (default) | float32 |
|---|---|---|
| fit | about 0.9 s | about 0.7 s |
| transform | about 0.3 s | about 0.4 s |
| processed output size | 21.6 MB | 10.8 MB |

- `DataPreprocessor` copies **only the columns it uses**, so unused columns add no memory.
- `output_dtype="float32"` halves the size of the processed data (use it for large data; keep float64 when you need full numeric precision).
- `clean_data` copies the whole frame by default so the caller's data is never modified. `copy=False` skips that copy but then modifies the
  input in place; it saved only about 7% of peak memory in the same measurement, so it is a minor option.
- **Stage timings** are printed at the end of every run and stored in `results.json`; `--profile` also records peak Python memory per stage
  (via `tracemalloc`, which slows the run, so it is off by default). On the 1,000-row dataset: loading 0.006 s, preprocessing 0.07 to 0.23 s,
  feature engineering and selection about 0.17 s (peak 1.7 MB), the 15 validation checks about 1 s, and the full
  `--compare-features --compare-models` comparison (about 16 scenarios of 15 cross-validation fits each, plus Ridge and tree models) about 163 s.
  Nearly all of that time is model fitting inside cross-validation, not feature creation.
- The pipeline works on in-memory pandas DataFrames. For data that does not fit in memory it would need chunked or out-of-core processing,
  which is not implemented. `LassoCV` selection is the slowest optional step because it cross-validates.

## Scope decisions

- **No temporal features.** Lags, rolling statistics, seasonality and "time since" features were deliberately left out: the dataset contains no
  timestamp or date column, so there is nothing to derive them from. If dated sales were added, a time-aware split (train on earlier, test on later
  data) would also be needed instead of the random stratified split.
- **No higher-cardinality columns in this dataset.** The extra encoders exist so the pipeline is reusable, and they are tested and demonstrated on
  synthetic data only. They were not needed for the housing data, where one-hot encoding of `location_type` is used.
- **No class-balancing methods.** This is a regression problem, so oversampling and class weights do not apply. The split report instead
  checks that the stratification column and the target distribution are preserved.

## Developer tooling

```bash
pip install -r requirements-dev.txt
ruff check . && ruff format --check .    # lint and formatting (configured in pyproject.toml)
mypy                                     # static type check of src/ and main.py
pre-commit install                       # run the checks automatically on every commit (and the tests before every push)
```

The GitHub Actions workflow (`.github/workflows/ci.yml`) runs the unit tests and the validation suite on Python 3.9, 3.11 and 3.12, and lint, format and type checks on 3.12.
The workflow has not been executed yet (it needs the repository on GitHub); everything in this repository was run locally on Python 3.12 only, so 3.9 and 3.11 support is intended but unverified.
The type checker is configured leniently because scikit-learn's estimator API (attributes created in `fit`) does not fit strict typing; the code in
`src/` and `main.py` is annotated and currently passes `mypy` and `ruff` with no findings.

## Assumptions and limitations

- Preprocessing expects the column names of this dataset; other datasets need an updated config.
- Stratification is on `location_type` only. The split report shows that the target itself can still differ between
  train and test (here the test set happens to contain the most expensive homes, so its skew is higher); with a small dataset a repeated or
  cross-validated evaluation is more reliable than one split.
- The extra encoders, KNN imputation and per-column strategies add flexibility but add no accuracy on this dataset (no missing values, one 3-level categorical column).
- Feature selection built into the preprocessor is optional and off by default: with only 8 predictors and low multicollinearity (VIF at most about 2.8) the EDA found nothing to remove.
- `proximity_to_public_transport` has a counterintuitive positive relation with price. It is
  kept as is; confirm its definition with the data owner before interpreting it.
- Clipping and log floors are learned from 800 training rows, so the Rural group (about 80 rows in
  training) contributes little to those statistics.
